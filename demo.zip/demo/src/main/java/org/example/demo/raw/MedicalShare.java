import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.fisco.bcos.sdk.abi.FunctionReturnDecoder;
import org.fisco.bcos.sdk.abi.TypeReference;
import org.fisco.bcos.sdk.abi.datatypes.Address;
import org.fisco.bcos.sdk.abi.datatypes.Bool;
import org.fisco.bcos.sdk.abi.datatypes.Event;
import org.fisco.bcos.sdk.abi.datatypes.Function;
import org.fisco.bcos.sdk.abi.datatypes.Type;
import org.fisco.bcos.sdk.abi.datatypes.Utf8String;
import org.fisco.bcos.sdk.abi.datatypes.generated.Uint256;
import org.fisco.bcos.sdk.abi.datatypes.generated.tuples.generated.Tuple1;
import org.fisco.bcos.sdk.abi.datatypes.generated.tuples.generated.Tuple2;
import org.fisco.bcos.sdk.abi.datatypes.generated.tuples.generated.Tuple6;
import org.fisco.bcos.sdk.client.Client;
import org.fisco.bcos.sdk.contract.Contract;
import org.fisco.bcos.sdk.crypto.CryptoSuite;
import org.fisco.bcos.sdk.crypto.keypair.CryptoKeyPair;
import org.fisco.bcos.sdk.eventsub.EventCallback;
import org.fisco.bcos.sdk.model.CryptoType;
import org.fisco.bcos.sdk.model.TransactionReceipt;
import org.fisco.bcos.sdk.model.callback.TransactionCallback;
import org.fisco.bcos.sdk.transaction.model.exception.ContractException;

@SuppressWarnings("unchecked")
public class MedicalShare extends Contract {
    public static final String[] BINARY_ARRAY = {"608060405234801561001057600080fd5b5033600360006101000a81548173ffffffffffffffffffffffffffffffffffffffff021916908373ffffffffffffffffffffffffffffffffffffffff160217905550611650806100616000396000f300608060405260043610610077576000357c0100000000000000000000000000000000000000000000000000000000900463ffffffff1680624eb9ca1461007c5780631b470bc7146100bf57806321ef1a99146101025780636f77926b1461028d57806377032f6f14610500578063c49b09b51461054f575b600080fd5b34801561008857600080fd5b506100bd600480360381019080803573ffffffffffffffffffffffffffffffffffffffff1690602001909291905050506105aa565b005b3480156100cb57600080fd5b50610100600480360381019080803573ffffffffffffffffffffffffffffffffffffffff169060200190929190505050610737565b005b34801561010e57600080fd5b5061028b600480360381019080803590602001908201803590602001908080601f0160208091040260200160405190810160405280939291908181526020018383808284378201915050505050509192919290803590602001908201803590602001908080601f016020809104026020016040519081016040528093929190818152602001838380828437820191505050505050919291929080359060200190929190803590602001908201803590602001908080601f0160208091040260200160405190810160405280939291908181526020018383808284378201915050505050509192919290803590602001908201803590602001908080601f0160208091040260200160405190810160405280939291908181526020018383808284378201915050505050509192919290803590602001908201803590602001908080601f016020809104026020016040519081016040528093929190818152602001838380828437820191505050505050919291929050505061087d565b005b34801561029957600080fd5b506102ce600480360381019080803573ffffffffffffffffffffffffffffffffffffffff169060200190929190505050610bfe565b60405180806020018060200187815260200180602001806020018060200186810386528c818151815260200191508051906020019080838360005b83811015610324578082015181840152602081019050610309565b50505050905090810190601f1680156103515780820380516001836020036101000a031916815260200191505b5086810385528b818151815260200191508051906020019080838360005b8381101561038a57808201518184015260208101905061036f565b50505050905090810190601f1680156103b75780820380516001836020036101000a031916815260200191505b50868103845289818151815260200191508051906020019080838360005b838110156103f05780820151818401526020810190506103d5565b50505050905090810190601f16801561041d5780820380516001836020036101000a031916815260200191505b50868103835288818151815260200191508051906020019080838360005b8381101561045657808201518184015260208101905061043b565b50505050905090810190601f1680156104835780820380516001836020036101000a031916815260200191505b50868103825287818151815260200191508051906020019080838360005b838110156104bc5780820151818401526020810190506104a1565b50505050905090810190601f1680156104e95780820380516001836020036101000a031916815260200191505b509b50505050505050505050505060405180910390f35b34801561050c57600080fd5b5061054d600480360381019080803573ffffffffffffffffffffffffffffffffffffffff16906020019092919080351515906020019092919050505061112d565b005b34801561055b57600080fd5b50610590600480360381019080803573ffffffffffffffffffffffffffffffffffffffff1690602001909291905050506113d1565b604051808215151515815260200191505060405180910390f35b600460003373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060009054906101000a900460ff161515610691576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825260258152602001807f4f6e6c7920686f73706974616c2063616e2063616c6c20746869732066756e6381526020017f74696f6e2e00000000000000000000000000000000000000000000000000000081525060400191505060405180910390fd5b600160008273ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1681526020019081526020016000203390806001815401808255809150509060018203906000526020600020016000909192909190916101000a81548173ffffffffffffffffffffffffffffffffffffffff021916908373ffffffffffffffffffffffffffffffffffffffff1602179055505050565b600360009054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff163373ffffffffffffffffffffffffffffffffffffffff16141515610822576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825260228152602001807f4f6e6c79206f776e65722063616e2063616c6c20746869732066756e6374696f81526020017f6e2e00000000000000000000000000000000000000000000000000000000000081525060400191505060405180910390fd5b6001600460008373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060006101000a81548160ff02191690831515021790555050565b60c060405190810160405280878152602001868152602001858152602001848152602001838152602001828152506000803373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1681526020019081526020016000206000820151816000019080519060200190610905929190611548565b506020820151816001019080519060200190610922929190611548565b50604082015181600201556060820151816003019080519060200190610949929190611548565b506080820151816004019080519060200190610966929190611548565b5060a0820151816005019080519060200190610983929190611548565b509050503373ffffffffffffffffffffffffffffffffffffffff167fa43f52b2e383520a219bafd19632cbabf7bd564e6732e0126cdac163e80177bf87878787878760405180806020018060200187815260200180602001806020018060200186810386528c818151815260200191508051906020019080838360005b83811015610a1b578082015181840152602081019050610a00565b50505050905090810190601f168015610a485780820380516001836020036101000a031916815260200191505b5086810385528b818151815260200191508051906020019080838360005b83811015610a81578082015181840152602081019050610a66565b50505050905090810190601f168015610aae5780820380516001836020036101000a031916815260200191505b50868103845289818151815260200191508051906020019080838360005b83811015610ae7578082015181840152602081019050610acc565b50505050905090810190601f168015610b145780820380516001836020036101000a031916815260200191505b50868103835288818151815260200191508051906020019080838360005b83811015610b4d578082015181840152602081019050610b32565b50505050905090810190601f168015610b7a5780820380516001836020036101000a031916815260200191505b50868103825287818151815260200191508051906020019080838360005b83811015610bb3578082015181840152602081019050610b98565b50505050905090810190601f168015610be05780820380516001836020036101000a031916815260200191505b509b50505050505050505050505060405180910390a2505050505050565b60608060006060806060610c106115c8565b8773ffffffffffffffffffffffffffffffffffffffff163373ffffffffffffffffffffffffffffffffffffffff161480610cd05750600560008973ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060003373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060009054906101000a900460ff165b1515610d6a576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825260368152602001807f596f7520617265206e6f7420617574686f72697a656420746f2067657420746881526020017f69732075736572277320696e666f726d6174696f6e2e0000000000000000000081525060400191505060405180910390fd5b6000808973ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060c06040519081016040529081600082018054600181600116156101000203166002900480601f016020809104026020016040519081016040528092919081815260200182805460018160011615610100020316600290048015610e4d5780601f10610e2257610100808354040283529160200191610e4d565b820191906000526020600020905b815481529060010190602001808311610e3057829003601f168201915b50505050508152602001600182018054600181600116156101000203166002900480601f016020809104026020016040519081016040528092919081815260200182805460018160011615610100020316600290048015610eef5780601f10610ec457610100808354040283529160200191610eef565b820191906000526020600020905b815481529060010190602001808311610ed257829003601f168201915b5050505050815260200160028201548152602001600382018054600181600116156101000203166002900480601f016020809104026020016040519081016040528092919081815260200182805460018160011615610100020316600290048015610f9b5780601f10610f7057610100808354040283529160200191610f9b565b820191906000526020600020905b815481529060010190602001808311610f7e57829003601f168201915b505050","50508152602001600482018054600181600116156101000203166002900480601f01602080910402602001604051908101604052809291908181526020018280546001816001161561010002031660029004801561103d5780601f106110125761010080835404028352916020019161103d565b820191906000526020600020905b81548152906001019060200180831161102057829003601f168201915b50505050508152602001600582018054600181600116156101000203166002900480601f0160208091040260200160405190810160405280929190818152602001828054600181600116156101000203166002900480156110df5780601f106110b4576101008083540402835291602001916110df565b820191906000526020600020905b8154815290600101906020018083116110c257829003601f168201915b5050505050815250509050806000015181602001518260400151836060015184608001518560a001518595508494508292508191508090509650965096509650965096505091939550919395565b60008060008060003373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060000180546001816001161561010002031660029004905014151515611224576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825260218152602001807f4f6e6c7920757365722063616e2063616c6c20746869732066756e6374696f6e81526020017f2e0000000000000000000000000000000000000000000000000000000000000081525060400191505060405180910390fd5b600160003373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1681526020019081526020016000209150600090505b81805490508110156113cb578373ffffffffffffffffffffffffffffffffffffffff16828281548110151561129b57fe5b9060005260206000200160009054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1614156113be57821561137e576001600560003373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060008673ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060006101000a81548160ff0219169083151502179055505b818181548110151561138c57fe5b9060005260206000200160006101000a81549073ffffffffffffffffffffffffffffffffffffffff02191690556113cb565b808060010191505061126a565b50505050565b6000600360009054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff163373ffffffffffffffffffffffffffffffffffffffff16148061145a57508173ffffffffffffffffffffffffffffffffffffffff163373ffffffffffffffffffffffffffffffffffffffff16145b15156114f4576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825260358152602001807f596f7520617265206e6f7420617574686f72697a656420746f2067657420746881526020017f697320686f73706974616c2773207374617475732e000000000000000000000081525060400191505060405180910390fd5b600460008373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060009054906101000a900460ff169050919050565b828054600181600116156101000203166002900490600052602060002090601f016020900481019282601f1061158957805160ff19168380011785556115b7565b828001600101855582156115b7579182015b828111156115b657825182559160200191906001019061159b565b5b5090506115c491906115ff565b5090565b60c0604051908101604052806060815260200160608152602001600081526020016060815260200160608152602001606081525090565b61162191905b8082111561161d576000816000905550600101611605565b5090565b905600a165627a7a723058201f0ee976b4b631b4f286e4668b1b06e56f5ba82338484010f54a42b3fb45b2e20029"};

    public static final String BINARY = org.fisco.bcos.sdk.utils.StringUtils.joinAll("", BINARY_ARRAY);

    public static final String[] SM_BINARY_ARRAY = {};

    public static final String SM_BINARY = org.fisco.bcos.sdk.utils.StringUtils.joinAll("", SM_BINARY_ARRAY);

    public static final String[] ABI_ARRAY = {"[{\"constant\":false,\"inputs\":[{\"name\":\"_user\",\"type\":\"address\"}],\"name\":\"requestUser\",\"outputs\":[],\"payable\":false,\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"constant\":false,\"inputs\":[{\"name\":\"_hospital\",\"type\":\"address\"}],\"name\":\"addHospital\",\"outputs\":[],\"payable\":false,\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"constant\":false,\"inputs\":[{\"name\":\"_name\",\"type\":\"string\"},{\"name\":\"_gender\",\"type\":\"string\"},{\"name\":\"_age\",\"type\":\"uint256\"},{\"name\":\"_history\",\"type\":\"string\"},{\"name\":\"_diagnosis\",\"type\":\"string\"},{\"name\":\"_treatmentPlan\",\"type\":\"string\"}],\"name\":\"addUser\",\"outputs\":[],\"payable\":false,\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[{\"name\":\"_user\",\"type\":\"address\"}],\"name\":\"getUser\",\"outputs\":[{\"name\":\"\",\"type\":\"string\"},{\"name\":\"\",\"type\":\"string\"},{\"name\":\"\",\"type\":\"uint256\"},{\"name\":\"\",\"type\":\"string\"},{\"name\":\"\",\"type\":\"string\"},{\"name\":\"\",\"type\":\"string\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":false,\"inputs\":[{\"name\":\"_hospital\",\"type\":\"address\"},{\"name\":\"_approve\",\"type\":\"bool\"}],\"name\":\"approveUser\",\"outputs\":[],\"payable\":false,\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[{\"name\":\"_hospital\",\"type\":\"address\"}],\"name\":\"getHospital\",\"outputs\":[{\"name\":\"\",\"type\":\"bool\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[],\"payable\":false,\"stateMutability\":\"nonpayable\",\"type\":\"constructor\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":true,\"name\":\"user\",\"type\":\"address\"},{\"indexed\":false,\"name\":\"name\",\"type\":\"string\"},{\"indexed\":false,\"name\":\"gender\",\"type\":\"string\"},{\"indexed\":false,\"name\":\"age\",\"type\":\"uint256\"},{\"indexed\":false,\"name\":\"history\",\"type\":\"string\"},{\"indexed\":false,\"name\":\"diagnosis\",\"type\":\"string\"},{\"indexed\":false,\"name\":\"treatmentPlan\",\"type\":\"string\"}],\"name\":\"UserAdded\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":true,\"name\":\"user\",\"type\":\"address\"},{\"indexed\":true,\"name\":\"hospital\",\"type\":\"address\"}],\"name\":\"UserRequested\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":true,\"name\":\"user\",\"type\":\"address\"},{\"indexed\":true,\"name\":\"hospital\",\"type\":\"address\"},{\"indexed\":false,\"name\":\"approve\",\"type\":\"bool\"}],\"name\":\"UserApproved\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":true,\"name\":\"hospital\",\"type\":\"address\"}],\"name\":\"HospitalAdded\",\"type\":\"event\"}]"};

    public static final String ABI = org.fisco.bcos.sdk.utils.StringUtils.joinAll("", ABI_ARRAY);

    public static final String FUNC_REQUESTUSER = "requestUser";

    public static final String FUNC_ADDHOSPITAL = "addHospital";

    public static final String FUNC_ADDUSER = "addUser";

    public static final String FUNC_GETUSER = "getUser";

    public static final String FUNC_APPROVEUSER = "approveUser";

    public static final String FUNC_GETHOSPITAL = "getHospital";

    public static final Event USERADDED_EVENT = new Event("UserAdded", 
            Arrays.<TypeReference<?>>asList(new TypeReference<Address>(true) {}, new TypeReference<Utf8String>() {}, new TypeReference<Utf8String>() {}, new TypeReference<Uint256>() {}, new TypeReference<Utf8String>() {}, new TypeReference<Utf8String>() {}, new TypeReference<Utf8String>() {}));
    ;

    public static final Event USERREQUESTED_EVENT = new Event("UserRequested", 
            Arrays.<TypeReference<?>>asList(new TypeReference<Address>(true) {}, new TypeReference<Address>(true) {}));
    ;

    public static final Event USERAPPROVED_EVENT = new Event("UserApproved", 
            Arrays.<TypeReference<?>>asList(new TypeReference<Address>(true) {}, new TypeReference<Address>(true) {}, new TypeReference<Bool>() {}));
    ;

    public static final Event HOSPITALADDED_EVENT = new Event("HospitalAdded", 
            Arrays.<TypeReference<?>>asList(new TypeReference<Address>(true) {}));
    ;

    protected MedicalShare(String contractAddress, Client client, CryptoKeyPair credential) {
        super(getBinary(client.getCryptoSuite()), contractAddress, client, credential);
    }

    public static String getBinary(CryptoSuite cryptoSuite) {
        return (cryptoSuite.getCryptoTypeConfig() == CryptoType.ECDSA_TYPE ? BINARY : SM_BINARY);
    }

    public TransactionReceipt requestUser(String _user) {
        final Function function = new Function(
                FUNC_REQUESTUSER, 
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Address(_user)), 
                Collections.<TypeReference<?>>emptyList());
        return executeTransaction(function);
    }

    public void requestUser(String _user, TransactionCallback callback) {
        final Function function = new Function(
                FUNC_REQUESTUSER, 
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Address(_user)), 
                Collections.<TypeReference<?>>emptyList());
        asyncExecuteTransaction(function, callback);
    }

    public String getSignedTransactionForRequestUser(String _user) {
        final Function function = new Function(
                FUNC_REQUESTUSER, 
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Address(_user)), 
                Collections.<TypeReference<?>>emptyList());
        return createSignedTransaction(function);
    }

    public Tuple1<String> getRequestUserInput(TransactionReceipt transactionReceipt) {
        String data = transactionReceipt.getInput().substring(10);
        final Function function = new Function(FUNC_REQUESTUSER, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Address>() {}));
        List<Type> results = FunctionReturnDecoder.decode(data, function.getOutputParameters());
        return new Tuple1<String>(

                (String) results.get(0).getValue()
                );
    }

    public TransactionReceipt addHospital(String _hospital) {
        final Function function = new Function(
                FUNC_ADDHOSPITAL, 
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Address(_hospital)), 
                Collections.<TypeReference<?>>emptyList());
        return executeTransaction(function);
    }

    public void addHospital(String _hospital, TransactionCallback callback) {
        final Function function = new Function(
                FUNC_ADDHOSPITAL, 
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Address(_hospital)), 
                Collections.<TypeReference<?>>emptyList());
        asyncExecuteTransaction(function, callback);
    }

    public String getSignedTransactionForAddHospital(String _hospital) {
        final Function function = new Function(
                FUNC_ADDHOSPITAL, 
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Address(_hospital)), 
                Collections.<TypeReference<?>>emptyList());
        return createSignedTransaction(function);
    }

    public Tuple1<String> getAddHospitalInput(TransactionReceipt transactionReceipt) {
        String data = transactionReceipt.getInput().substring(10);
        final Function function = new Function(FUNC_ADDHOSPITAL, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Address>() {}));
        List<Type> results = FunctionReturnDecoder.decode(data, function.getOutputParameters());
        return new Tuple1<String>(

                (String) results.get(0).getValue()
                );
    }

    public TransactionReceipt addUser(String _name, String _gender, BigInteger _age, String _history, String _diagnosis, String _treatmentPlan) {
        final Function function = new Function(
                FUNC_ADDUSER, 
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Utf8String(_name), 
                new org.fisco.bcos.sdk.abi.datatypes.Utf8String(_gender), 
                new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(_age), 
                new org.fisco.bcos.sdk.abi.datatypes.Utf8String(_history), 
                new org.fisco.bcos.sdk.abi.datatypes.Utf8String(_diagnosis), 
                new org.fisco.bcos.sdk.abi.datatypes.Utf8String(_treatmentPlan)), 
                Collections.<TypeReference<?>>emptyList());
        return executeTransaction(function);
    }

    public void addUser(String _name, String _gender, BigInteger _age, String _history, String _diagnosis, String _treatmentPlan, TransactionCallback callback) {
        final Function function = new Function(
                FUNC_ADDUSER, 
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Utf8String(_name), 
                new org.fisco.bcos.sdk.abi.datatypes.Utf8String(_gender), 
                new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(_age), 
                new org.fisco.bcos.sdk.abi.datatypes.Utf8String(_history), 
                new org.fisco.bcos.sdk.abi.datatypes.Utf8String(_diagnosis), 
                new org.fisco.bcos.sdk.abi.datatypes.Utf8String(_treatmentPlan)), 
                Collections.<TypeReference<?>>emptyList());
        asyncExecuteTransaction(function, callback);
    }

    public String getSignedTransactionForAddUser(String _name, String _gender, BigInteger _age, String _history, String _diagnosis, String _treatmentPlan) {
        final Function function = new Function(
                FUNC_ADDUSER, 
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Utf8String(_name), 
                new org.fisco.bcos.sdk.abi.datatypes.Utf8String(_gender), 
                new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(_age), 
                new org.fisco.bcos.sdk.abi.datatypes.Utf8String(_history), 
                new org.fisco.bcos.sdk.abi.datatypes.Utf8String(_diagnosis), 
                new org.fisco.bcos.sdk.abi.datatypes.Utf8String(_treatmentPlan)), 
                Collections.<TypeReference<?>>emptyList());
        return createSignedTransaction(function);
    }

    public Tuple6<String, String, BigInteger, String, String, String> getAddUserInput(TransactionReceipt transactionReceipt) {
        String data = transactionReceipt.getInput().substring(10);
        final Function function = new Function(FUNC_ADDUSER, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}, new TypeReference<Utf8String>() {}, new TypeReference<Uint256>() {}, new TypeReference<Utf8String>() {}, new TypeReference<Utf8String>() {}, new TypeReference<Utf8String>() {}));
        List<Type> results = FunctionReturnDecoder.decode(data, function.getOutputParameters());
        return new Tuple6<String, String, BigInteger, String, String, String>(

                (String) results.get(0).getValue(), 
                (String) results.get(1).getValue(), 
                (BigInteger) results.get(2).getValue(), 
                (String) results.get(3).getValue(), 
                (String) results.get(4).getValue(), 
                (String) results.get(5).getValue()
                );
    }

    public Tuple6<String, String, BigInteger, String, String, String> getUser(String _user) throws ContractException {
        final Function function = new Function(FUNC_GETUSER, 
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Address(_user)), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}, new TypeReference<Utf8String>() {}, new TypeReference<Uint256>() {}, new TypeReference<Utf8String>() {}, new TypeReference<Utf8String>() {}, new TypeReference<Utf8String>() {}));
        List<Type> results = executeCallWithMultipleValueReturn(function);
        return new Tuple6<String, String, BigInteger, String, String, String>(
                (String) results.get(0).getValue(), 
                (String) results.get(1).getValue(), 
                (BigInteger) results.get(2).getValue(), 
                (String) results.get(3).getValue(), 
                (String) results.get(4).getValue(), 
                (String) results.get(5).getValue());
    }

    public TransactionReceipt approveUser(String _hospital, Boolean _approve) {
        final Function function = new Function(
                FUNC_APPROVEUSER, 
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Address(_hospital), 
                new org.fisco.bcos.sdk.abi.datatypes.Bool(_approve)), 
                Collections.<TypeReference<?>>emptyList());
        return executeTransaction(function);
    }

    public void approveUser(String _hospital, Boolean _approve, TransactionCallback callback) {
        final Function function = new Function(
                FUNC_APPROVEUSER, 
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Address(_hospital), 
                new org.fisco.bcos.sdk.abi.datatypes.Bool(_approve)), 
                Collections.<TypeReference<?>>emptyList());
        asyncExecuteTransaction(function, callback);
    }

    public String getSignedTransactionForApproveUser(String _hospital, Boolean _approve) {
        final Function function = new Function(
                FUNC_APPROVEUSER, 
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Address(_hospital), 
                new org.fisco.bcos.sdk.abi.datatypes.Bool(_approve)), 
                Collections.<TypeReference<?>>emptyList());
        return createSignedTransaction(function);
    }

    public Tuple2<String, Boolean> getApproveUserInput(TransactionReceipt transactionReceipt) {
        String data = transactionReceipt.getInput().substring(10);
        final Function function = new Function(FUNC_APPROVEUSER, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Address>() {}, new TypeReference<Bool>() {}));
        List<Type> results = FunctionReturnDecoder.decode(data, function.getOutputParameters());
        return new Tuple2<String, Boolean>(

                (String) results.get(0).getValue(), 
                (Boolean) results.get(1).getValue()
                );
    }

    public Boolean getHospital(String _hospital) throws ContractException {
        final Function function = new Function(FUNC_GETHOSPITAL, 
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Address(_hospital)), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Bool>() {}));
        return executeCallWithSingleValueReturn(function, Boolean.class);
    }

    public List<UserAddedEventResponse> getUserAddedEvents(TransactionReceipt transactionReceipt) {
        List<Contract.EventValuesWithLog> valueList = extractEventParametersWithLog(USERADDED_EVENT, transactionReceipt);
        ArrayList<UserAddedEventResponse> responses = new ArrayList<UserAddedEventResponse>(valueList.size());
        for (Contract.EventValuesWithLog eventValues : valueList) {
            UserAddedEventResponse typedResponse = new UserAddedEventResponse();
            typedResponse.log = eventValues.getLog();
            typedResponse.user = (String) eventValues.getIndexedValues().get(0).getValue();
            typedResponse.name = (String) eventValues.getNonIndexedValues().get(0).getValue();
            typedResponse.gender = (String) eventValues.getNonIndexedValues().get(1).getValue();
            typedResponse.age = (BigInteger) eventValues.getNonIndexedValues().get(2).getValue();
            typedResponse.history = (String) eventValues.getNonIndexedValues().get(3).getValue();
            typedResponse.diagnosis = (String) eventValues.getNonIndexedValues().get(4).getValue();
            typedResponse.treatmentPlan = (String) eventValues.getNonIndexedValues().get(5).getValue();
            responses.add(typedResponse);
        }
        return responses;
    }

    public void subscribeUserAddedEvent(String fromBlock, String toBlock, List<String> otherTopics, EventCallback callback) {
        String topic0 = eventEncoder.encode(USERADDED_EVENT);
        subscribeEvent(ABI,BINARY,topic0,fromBlock,toBlock,otherTopics,callback);
    }

    public void subscribeUserAddedEvent(EventCallback callback) {
        String topic0 = eventEncoder.encode(USERADDED_EVENT);
        subscribeEvent(ABI,BINARY,topic0,callback);
    }

    public List<UserRequestedEventResponse> getUserRequestedEvents(TransactionReceipt transactionReceipt) {
        List<Contract.EventValuesWithLog> valueList = extractEventParametersWithLog(USERREQUESTED_EVENT, transactionReceipt);
        ArrayList<UserRequestedEventResponse> responses = new ArrayList<UserRequestedEventResponse>(valueList.size());
        for (Contract.EventValuesWithLog eventValues : valueList) {
            UserRequestedEventResponse typedResponse = new UserRequestedEventResponse();
            typedResponse.log = eventValues.getLog();
            typedResponse.user = (String) eventValues.getIndexedValues().get(0).getValue();
            typedResponse.hospital = (String) eventValues.getIndexedValues().get(1).getValue();
            responses.add(typedResponse);
        }
        return responses;
    }

    public void subscribeUserRequestedEvent(String fromBlock, String toBlock, List<String> otherTopics, EventCallback callback) {
        String topic0 = eventEncoder.encode(USERREQUESTED_EVENT);
        subscribeEvent(ABI,BINARY,topic0,fromBlock,toBlock,otherTopics,callback);
    }

    public void subscribeUserRequestedEvent(EventCallback callback) {
        String topic0 = eventEncoder.encode(USERREQUESTED_EVENT);
        subscribeEvent(ABI,BINARY,topic0,callback);
    }

    public List<UserApprovedEventResponse> getUserApprovedEvents(TransactionReceipt transactionReceipt) {
        List<Contract.EventValuesWithLog> valueList = extractEventParametersWithLog(USERAPPROVED_EVENT, transactionReceipt);
        ArrayList<UserApprovedEventResponse> responses = new ArrayList<UserApprovedEventResponse>(valueList.size());
        for (Contract.EventValuesWithLog eventValues : valueList) {
            UserApprovedEventResponse typedResponse = new UserApprovedEventResponse();
            typedResponse.log = eventValues.getLog();
            typedResponse.user = (String) eventValues.getIndexedValues().get(0).getValue();
            typedResponse.hospital = (String) eventValues.getIndexedValues().get(1).getValue();
            typedResponse.approve = (Boolean) eventValues.getNonIndexedValues().get(0).getValue();
            responses.add(typedResponse);
        }
        return responses;
    }

    public void subscribeUserApprovedEvent(String fromBlock, String toBlock, List<String> otherTopics, EventCallback callback) {
        String topic0 = eventEncoder.encode(USERAPPROVED_EVENT);
        subscribeEvent(ABI,BINARY,topic0,fromBlock,toBlock,otherTopics,callback);
    }

    public void subscribeUserApprovedEvent(EventCallback callback) {
        String topic0 = eventEncoder.encode(USERAPPROVED_EVENT);
        subscribeEvent(ABI,BINARY,topic0,callback);
    }

    public List<HospitalAddedEventResponse> getHospitalAddedEvents(TransactionReceipt transactionReceipt) {
        List<Contract.EventValuesWithLog> valueList = extractEventParametersWithLog(HOSPITALADDED_EVENT, transactionReceipt);
        ArrayList<HospitalAddedEventResponse> responses = new ArrayList<HospitalAddedEventResponse>(valueList.size());
        for (Contract.EventValuesWithLog eventValues : valueList) {
            HospitalAddedEventResponse typedResponse = new HospitalAddedEventResponse();
            typedResponse.log = eventValues.getLog();
            typedResponse.hospital = (String) eventValues.getIndexedValues().get(0).getValue();
            responses.add(typedResponse);
        }
        return responses;
    }

    public void subscribeHospitalAddedEvent(String fromBlock, String toBlock, List<String> otherTopics, EventCallback callback) {
        String topic0 = eventEncoder.encode(HOSPITALADDED_EVENT);
        subscribeEvent(ABI,BINARY,topic0,fromBlock,toBlock,otherTopics,callback);
    }

    public void subscribeHospitalAddedEvent(EventCallback callback) {
        String topic0 = eventEncoder.encode(HOSPITALADDED_EVENT);
        subscribeEvent(ABI,BINARY,topic0,callback);
    }

    public static MedicalShare load(String contractAddress, Client client, CryptoKeyPair credential) {
        return new MedicalShare(contractAddress, client, credential);
    }

    public static MedicalShare deploy(Client client, CryptoKeyPair credential) throws ContractException {
        return deploy(MedicalShare.class, client, credential, getBinary(client.getCryptoSuite()), "");
    }

    public static class UserAddedEventResponse {
        public TransactionReceipt.Logs log;

        public String user;

        public String name;

        public String gender;

        public BigInteger age;

        public String history;

        public String diagnosis;

        public String treatmentPlan;
    }

    public static class UserRequestedEventResponse {
        public TransactionReceipt.Logs log;

        public String user;

        public String hospital;
    }

    public static class UserApprovedEventResponse {
        public TransactionReceipt.Logs log;

        public String user;

        public String hospital;

        public Boolean approve;
    }

    public static class HospitalAddedEventResponse {
        public TransactionReceipt.Logs log;

        public String hospital;
    }
}
