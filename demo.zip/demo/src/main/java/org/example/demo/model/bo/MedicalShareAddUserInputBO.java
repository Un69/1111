package org.example.demo.model.bo;

import java.lang.Object;
import java.lang.String;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MedicalShareAddUserInputBO {
  private String _name;

  private String _gender;

  private BigInteger _age;

  private String _history;

  private String _diagnosis;

  private String _treatmentPlan;

  public List<Object> toArgs() {
    List args = new ArrayList();
    args.add(_name);
    args.add(_gender);
    args.add(_age);
    args.add(_history);
    args.add(_diagnosis);
    args.add(_treatmentPlan);
    return args;
  }
}
