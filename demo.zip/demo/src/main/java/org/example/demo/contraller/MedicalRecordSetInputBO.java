package org.example.demo.model.bo;

public class MedicalRecordSetInputBO {
    private String name;
    private String gender;
    private int age;
    private String history;
    private String diagnosis;
    private String treatmentPlan;
    
    // Add constructor, getter and setter methods for the fields
}
