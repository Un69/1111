package com.example.medicalshare.service;

import com.example.medicalshare.contract.MedicalShare;
import org.fisco.bcos.sdk.BcosSDK;
import org.fisco.bcos.sdk.client.Client;
import org.fisco.bcos.sdk.model.CryptoType;
import org.fisco.bcos.sdk.transaction.model.exception.ContractException;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.math.BigInteger;

@Service
public class MedicalShareService {

    private MedicalShare medicalShareContract;
    private Client client;

    @PostConstruct
    public void init() {
        BcosSDK sdk = BcosSDK.build("src/main/resources/config.yaml");
        client = sdk.getClient(Integer.valueOf(1));
        String contractAddress = "0xb0c721f6648b20eec52edd1cb0a0d946b7b37b0d";
        medicalShareContract = MedicalShare.load(contractAddress, client, CryptoType.ECDSA_TYPE);
    }

    public void addUser(String name, String gender, int age, String history, String diagnosis, String treatmentPlan) throws ContractException {
        medicalShareContract.addUser(name, gender, BigInteger.valueOf(age), history, diagnosis, treatmentPlan).send();
    }

    public String[] getUser(String userAddress) throws ContractException {
        return medicalShareContract.getUser(userAddress).send();
    }

    // Add other contract interaction methods here...
}
