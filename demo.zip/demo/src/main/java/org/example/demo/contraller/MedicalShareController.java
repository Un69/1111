package org.example.demo.controller;

import org.example.demo.model.bo.MedicalRecordSetInputBO;
import org.example.demo.service.MedicalShareService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("medicalshare")
public class MedicalShareController {

    @Autowired
    private MedicalShareService service;

    @PostMapping("addUser")
    public String addUser(@RequestBody MedicalRecordSetInputBO input) throws Exception {
        return service.addUser(input).getTransactionReceipt().getTransactionHash();
    }

    @GetMapping("getUser")
    public String getUser(@RequestParam("userAddress") String userAddress) throws Exception {
        return service.getUser(userAddress).getValues();
    }

    @PostMapping("requestUser")
    public String requestUser(@RequestParam("userAddress") String userAddress) throws Exception {
        return service.requestUser(userAddress).getTransactionReceipt().getTransactionHash();
    }

    @PostMapping("approveUser")
    public String approveUser(@RequestParam("hospitalAddress") String hospitalAddress, @RequestParam("approve") boolean approve) throws Exception {
        return service.approveUser(hospitalAddress, approve).getTransactionReceipt().getTransactionHash();
    }
}
